function dataWithJson() {
  $.getJSON("team.json", function(data) {
    $('#team').empty(); // Clear the team div before adding new data
    $.each(data, function(index, teamMember) {
      var name = '<h2>' + teamMember.name + '</h2>';
      var position = '<h5>' + teamMember.position + '</h5>';
      var bio = '<p>' + teamMember.bio + '</p>';
      $('#team').append(name + position + bio);
    });
  });
}


function dataWithAjax() {
  const dataFile = "team.json";
  const teamData = $('#team');
  const teamLoadingMsg = "<h1>LOADING...</h1>";
  const contentData = $('#content');
  const team2Data = $('<div id="team2"></div>');
  const fadeInDelay = 3000; //for 3 sec delay
  
  teamData.append(teamLoadingMsg).hide(fadeInDelay);
  contentData.append(team2Data);
  team2Data.hide();
  
  $.ajax({
    dataType: "json",
    url: dataFile,
    type: "GET",
    success: function (data) {
      for (let i = 0; i < data.length; i++) {
        const teamMember = data[i];
        const teamMemberInfo = `
          <h2>${teamMember.name}</h2>
          <h5>${teamMember.position}</h5>
          <p>${teamMember.bio}</p>
        `;
        team2Data.append(teamMemberInfo);
      }
      setTimeout(function() {
        team2Data.fadeIn(500);
      }, fadeInDelay);
    },
    error: function() {
      teamData.append("The content could not be retrieved");
    }
  });
}

$(document).ready(function() {
  dataWithAjax();
});